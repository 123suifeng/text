### TSC: Transition State Clustering
Implements experiments to evaluate transition state clustering as described in: 

- Transition State Clustering: Unsupervised Surgical Trajectory Segmentation For Robot Learning. Sanjay Krishnan*, Animesh Garg*, Sachin Patil, Colin Lea, Greg Hager, Pieter Abbeel, Ken Goldberg (* denotes equal contribution).
International Symposium on Robotics Research (ISRR), 2015.

Please visit  [http://berkeleyautomation.github.io/tsc](http://berkeleyautomation.github.io/tsc) for more info
