You can see many .mat files when you run run_pascal.sh
Then you can get colourful segmentation results when you run create_labels.py
