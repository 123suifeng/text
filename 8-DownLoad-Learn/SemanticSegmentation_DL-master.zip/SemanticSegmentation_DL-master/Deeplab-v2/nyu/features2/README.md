Just a file folder
