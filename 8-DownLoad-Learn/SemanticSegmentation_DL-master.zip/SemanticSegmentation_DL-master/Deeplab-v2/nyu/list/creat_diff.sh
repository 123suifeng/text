#!/bin/sh

comm -3 ./train_all.txt ./val.txt > ./train_aug.txt
