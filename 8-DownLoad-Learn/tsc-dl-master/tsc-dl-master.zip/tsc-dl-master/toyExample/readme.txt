4 bits: varyRobotInit, noisyDynamics, varyTargetInit, targetNoise 

Experiments: 
1. Noisy targets : 0001
2. Varying robot initialization: 1000
3. Dynamics Noise: 0100
4. Noisy Target + Dynamics Noise: 0101
5. Noisy Target + vary robot init: 1001 
6. Noisy Target + vary robot init + Dynamics Noise: 1101

Strectch Goal
7. Vary target Init  + vary robot init + Dynamics Noise: 1110 (Hardest)
Varying target init and target noise are not necessary simultaneously. 


