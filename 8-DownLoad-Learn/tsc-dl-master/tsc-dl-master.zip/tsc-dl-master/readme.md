TSC-DL: Unsupervised Trajectory Segmentation of Multi-Modal Surgical Demonstrations with Deep Learning

Project Page:
http://berkeleyautomation.github.io/tsc-dl/