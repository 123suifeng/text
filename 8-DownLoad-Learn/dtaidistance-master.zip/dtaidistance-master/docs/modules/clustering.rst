

.. automodule:: dtaidistance.clustering
   :members:
