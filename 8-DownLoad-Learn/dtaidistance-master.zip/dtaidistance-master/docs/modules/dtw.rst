
.. automodule:: dtaidistance.dtw
   :members:
