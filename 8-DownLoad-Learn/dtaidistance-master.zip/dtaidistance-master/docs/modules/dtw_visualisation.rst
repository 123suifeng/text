
.. automodule:: dtaidistance.dtw_visualisation
   :members:
