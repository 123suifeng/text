=======
Credits
=======

Development Lead
----------------

* `@jakeret <https://github.com/jakeret>`_ 

Contributors
------------

* `@FelixGruen <https://github.com/FelixGruen>`_ 
* `@ameya005 <https://github.com/ameya005>`_ 
* `@agrafix  <https://github.com/agrafix>`_ 
* `@AlessioM  <https://github.com/AlessioM>`_ 
* `@FiLeonard  <https://github.com/FiLeonard>`_ 
* `@nikkou  <https://github.com/nikkou>`_ 

Citations
---------

As you use **tf_unet** for your exciting discoveries, please cite the paper that describes the package: 

`J. Akeret, C. Chang, A. Lucchi, A. Refregier, Published in Astronomy and Computing (2017) <https://arxiv.org/abs/1609.09077>`_
