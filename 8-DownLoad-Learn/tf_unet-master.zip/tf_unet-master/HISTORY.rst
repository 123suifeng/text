.. :changelog:

History
-------

0.1.1 (2017-12-29)
++++++++++++++++++

* Support for Tensorflow > 1.0.0
* Clean package structure
* Integration into mybinder

0.1.0 (2016-08-18)
++++++++++++++++++

* First release to GitHub.