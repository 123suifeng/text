k-means
===
C++ implements k-means algorithm

Chinese Details: http://www.cnblogs.com/luxiaoxun/archive/2013/05/09/3069594.html

GMM
===
C++ implemens GMM (Gaussian mixture model)

Chinese Details:http://www.cnblogs.com/luxiaoxun/archive/2013/05/10/3071672.htm

HMM
===
C++ implements HMM (Hidden Markov Model) based on k-means and GMM

Chinese Details:http://www.cnblogs.com/luxiaoxun/archive/2013/05/12/3074510.html
